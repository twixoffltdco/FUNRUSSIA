#include <a_samp>
#include <a_mysql>

/* Fun Russia 2FA filterscript
 * TOTP RFC 6238 / HMAC-SHA1, 6 digits, 30-second step.
 * Storage: automatically-created funrussia_2fa table keyed by accounts.id.
 * Purchase is opened from the existing EuroSystem FunCoin menu.
 * 2FA is prompted after spawn only when the IP differs from the last trusted IP.
 */
#if !defined MYSQL_INVALID_HANDLE
    #define MYSQL_INVALID_HANDLE (0)
#endif
#define MYSQL_FILE "bykranin_mysql_settings.ini"
#define COLOR_OK 0x55DD55FF
#define COLOR_ERR 0xFF5555FF
#define DLG_2FA_SETUP 29170
#define DLG_2FA_VERIFY 29171
#define DLG_2FA_CONFIRM 29172
#define SECRET_BYTES 20
#define SECRET_B32_LEN 33
#define MAX_SHA_BYTES 256

new MySQL:g2faSQL;
new g2faSQLHost[64], g2faSQLUser[64], g2faSQLPass[128], g2faSQLDB[64];
new g2faAccountID[MAX_PLAYERS];
new g2faAdminLevel[MAX_PLAYERS];
new g2faReminderTimer[MAX_PLAYERS];
new PlayerText:g2faReminderTD[MAX_PLAYERS][7];
new bool:g2faReminderVisible[MAX_PLAYERS];
new bool:g2faEnabled[MAX_PLAYERS];
new bool:g2faDataLoaded[MAX_PLAYERS];
new g2faLastIP[MAX_PLAYERS][46];
new bool:g2faPending[MAX_PLAYERS];
new bool:g2faSetupPending[MAX_PLAYERS];
new bool:g2faPassed[MAX_PLAYERS];
new g2faSecret[MAX_PLAYERS][SECRET_BYTES];
new g2faSecretText[MAX_PLAYERS][SECRET_B32_LEN];
new g2faFails[MAX_PLAYERS];
new g2faLastStep[MAX_PLAYERS];

forward FR2FA_ChargeFC(playerid, amount);
forward FR2FA_OpenPurchase(playerid);

public OnFilterScriptInit()
{
    g2faSQL = MYSQL_INVALID_HANDLE;
    if(!FR2FA_LoadIni() || !FR2FA_ConnectSQL())
    {
        print("[FunRussia 2FA] ERROR: cannot connect to MySQL using bykranin_mysql_settings.ini");
        return 1;
    }
    new query[512];
    format(query, sizeof query, "CREATE TABLE IF NOT EXISTS `funrussia_2fa` (`account_id` INT NOT NULL PRIMARY KEY, `enabled` TINYINT(1) NOT NULL DEFAULT 0, `secret` VARCHAR(64) NOT NULL DEFAULT '', `trusted_ip` VARCHAR(45) NOT NULL DEFAULT '', `setup_paid` TINYINT(1) NOT NULL DEFAULT 0) ENGINE=InnoDB DEFAULT CHARSET=cp1251");
    mysql_query(g2faSQL, query, false);
    if(mysql_errno(g2faSQL) != 0) print("[FunRussia 2FA] ERROR: cannot create funrussia_2fa table");
    else print("[FunRussia 2FA] MySQL connected; table ensured. Load EuroSystem before this filterscript.");
    return 1;
}

public OnFilterScriptExit()
{
    if(g2faSQL != MYSQL_INVALID_HANDLE) mysql_close(g2faSQL);
    return 1;
}

// Opened only from EuroSystem's existing FunCoin shop menu. No chat commands.
public FR2FA_OpenPurchase(playerid)
{
    if(!IsPlayerConnected(playerid)) return 0;
    FR2FA_HideAdminReminder(playerid);
    // Load the current account directly from MySQL; no gamemode patch is required.
    if(!FR2FA_LoadAccountData(playerid))
    {
        SendClientMessage(playerid, COLOR_ERR, "�� ������� ��������� ��������� 2FA �� ���� ������.");
        return 1;
    }
    if(g2faEnabled[playerid])
    {
        SendClientMessage(playerid, COLOR_OK, "� ��� ��� ������� � ��������� ������ 2FA.");
        return 1;
    }
    if(g2faSecretText[playerid][0])
    {
        // Paid previously but setup wasn't completed: continue for free.
        g2faSetupPending[playerid] = true;
        FR2FA_ShowSecret(playerid);
        return 1;
    }
    ShowPlayerDialog(playerid, DLG_2FA_SETUP, DIALOG_STYLE_MSGBOX,
        "����������� 2FA",
        "������ �������� ����� 1000 FC. ����� ������ �������� ��������� ���� ��� Google Authenticator. ���� �� �������� ���������, ����� ��������� ���� � ���������� ��� ��������� ������.",
        "������ �� 1000 FC", "������");
    return 1;
}

public OnPlayerConnect(playerid)
{
    g2faAccountID[playerid] = 0;
    g2faAdminLevel[playerid] = 0;
    g2faReminderTimer[playerid] = 0;
    g2faReminderVisible[playerid] = false;
    g2faEnabled[playerid] = false;
    g2faPending[playerid] = false;
    g2faSetupPending[playerid] = false;
    g2faPassed[playerid] = false;
    g2faDataLoaded[playerid] = false;
    g2faFails[playerid] = 0;
    g2faLastStep[playerid] = -1;
    g2faSecretText[playerid][0] = EOS;
    g2faLastIP[playerid][0] = EOS;
    return 1;
}

public OnPlayerDisconnect(playerid, reason)
{
    #pragma unused reason
    if(g2faReminderTimer[playerid]) KillTimer(g2faReminderTimer[playerid]);
    g2faReminderTimer[playerid] = 0;
    FR2FA_HideAdminReminder(playerid);
    if(g2faPending[playerid]) TogglePlayerControllable(playerid, 1);
    g2faPending[playerid] = false;
    g2faSetupPending[playerid] = false;
    g2faPassed[playerid] = false;
    g2faDataLoaded[playerid] = false;
    return 1;
}

public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    #pragma unused listitem
    if(dialogid == DLG_2FA_SETUP)
    {
        if(!response) return 1;
        if(!g2faDataLoaded[playerid] && !FR2FA_LoadAccountData(playerid))
        {
            SendClientMessage(playerid, COLOR_ERR, "MySQL 2FA ����������. ���������� �����.");
            return 1;
        }
        if(g2faEnabled[playerid])
        {
            SendClientMessage(playerid, COLOR_OK, "� ��� ��� ������� � ��������� ������ 2FA.");
            return 1;
        }
        if(g2faSecretText[playerid][0])
        {
            g2faSetupPending[playerid] = true;
            FR2FA_ShowSecret(playerid);
            return 1;
        }
        if(CallRemoteFunction("FR2FA_ChargeFC", "ii", playerid, 1000) != 1)
        {
            SendClientMessage(playerid, COLOR_ERR, "������������ FC ��� EuroSystem �� ���� ������� ������.");
            return 1;
        }
        FR2FA_GenerateSecret(playerid);
        new ip[46]; GetPlayerIp(playerid, ip, sizeof ip);
        if(!FR2FA_SaveAccountData(playerid, 0, g2faSecretText[playerid], ip, 1))
        {
            CallRemoteFunction("FR2FA_RefundFC", "ii", playerid, 1000);
            SendClientMessage(playerid, COLOR_ERR, "�� ������� ��������� ������� � ����. ������� �������� 1000 FC ���������; ���������� � �������������, ���� ������ �� ���������.");
            return 1;
        }
        format(g2faLastIP[playerid], sizeof g2faLastIP[], "%s", ip);
        g2faSetupPending[playerid] = true;
        FR2FA_ShowSecret(playerid);
        return 1;
    }
    if(dialogid == DLG_2FA_CONFIRM)
    {
        if(response) ShowPlayerDialog(playerid, DLG_2FA_VERIFY, DIALOG_STYLE_INPUT,
            "������������� 2FA", "������� ������� 6-������� ��� ����������, ����� ��������� �����������:", "�����������", "�����");
        return 1;
    }
    if(dialogid == DLG_2FA_VERIFY)
    {
        if(!response)
        {
            if(g2faPending[playerid])
            {
                ShowPlayerDialog(playerid, DLG_2FA_VERIFY, DIALOG_STYLE_INPUT,
                    "��������� 2FA", "��� ����������� ���� ������� 6-������� ��� Google Authenticator:", "�����������", "�����");
            }
            return 1;
        }
        if(!g2faSecretText[playerid][0] || !FR2FA_Base32Decode(g2faSecretText[playerid], g2faSecret[playerid], SECRET_BYTES))
        {
            SendClientMessage(playerid, COLOR_ERR, "������ 2FA ����������� ��� ��������. ���������� � �������������.");
            return 1;
        }
        if(FR2FA_Verify(playerid, inputtext))
        {
            g2faFails[playerid] = 0;
            new ip[46]; GetPlayerIp(playerid, ip, sizeof ip);
            if(g2faSetupPending[playerid])
            {
                if(!FR2FA_SaveAccountData(playerid, 1, g2faSecretText[playerid], ip, 1))
                {
                    SendClientMessage(playerid, COLOR_ERR, "�� ������� ��������� ��������� 2FA � ���� ������.");
                    return 1;
                }
                g2faEnabled[playerid] = true;
                if(g2faReminderTimer[playerid]) KillTimer(g2faReminderTimer[playerid]);
                g2faReminderTimer[playerid] = 0;
                g2faSetupPending[playerid] = false;
                format(g2faLastIP[playerid], sizeof g2faLastIP[], "%s", ip);
                SendClientMessage(playerid, COLOR_OK, "2FA �������� � ��������� � ���� ������. ��������� ��������� ����� ���������� �����.");
            }
            else if(g2faPending[playerid])
            {
                if(!FR2FA_SaveAccountData(playerid, 1, g2faSecretText[playerid], ip, 1))
                {
                    SendClientMessage(playerid, COLOR_ERR, "�� ������� ��������� ���������� IP � ���� ������.");
                    return 1;
                }
                format(g2faLastIP[playerid], sizeof g2faLastIP[], "%s", ip);
                g2faPending[playerid] = false;
                g2faPassed[playerid] = true;
                if(g2faReminderTimer[playerid]) KillTimer(g2faReminderTimer[playerid]);
                g2faReminderTimer[playerid] = 0;
                TogglePlayerControllable(playerid, 1);
                SendClientMessage(playerid, COLOR_OK, "��� 2FA ����������. ���� IP �������� ��� ����������.");
            }
            else SendClientMessage(playerid, COLOR_OK, "��� 2FA ����������.");
        }
        else
        {
            g2faFails[playerid]++;
            SendClientMessage(playerid, COLOR_ERR, "�������� ���. ��������� ����� �� �������� � ���������� ��� ���.");
            if(g2faFails[playerid] >= 3) Kick(playerid);
            else ShowPlayerDialog(playerid, DLG_2FA_VERIFY, DIALOG_STYLE_INPUT,
                "�������� ���", "������� ������� 6-������� ��� Google Authenticator:", "���������", "�����");
        }
        return 1;
    }
    return 0;
}

// Spawn gate: the filterscript reads the account directly and freezes only when 2FA is required.
public OnPlayerSpawn(playerid)
{
    g2faPassed[playerid] = false;
    if(g2faReminderTimer[playerid]) KillTimer(g2faReminderTimer[playerid]);
    g2faReminderTimer[playerid] = 0;
    FR2FA_LoadAccountData(playerid);
    if(g2faAdminLevel[playerid] >= 5 && g2faAdminLevel[playerid] <= 13 && !g2faEnabled[playerid])
    {
        FR2FA_ShowAdminReminder(playerid);
        g2faReminderTimer[playerid] = SetTimerEx("FR2FA_AdminReminderTimer", 300000, true, "i", playerid);
    }
    return 1;
}

forward FR2FA_AdminReminderTimer(playerid);
public FR2FA_AdminReminderTimer(playerid)
{
    if(!IsPlayerConnected(playerid) || g2faAdminLevel[playerid] < 5 || g2faAdminLevel[playerid] > 13 || g2faEnabled[playerid] || g2faPending[playerid]) return 1;
    FR2FA_ShowAdminReminder(playerid);
    return 1;
}

stock FR2FA_ShowAdminReminder(playerid)
{
    if(!IsPlayerConnected(playerid) || g2faEnabled[playerid] || g2faPending[playerid]) return 0;
    if(g2faReminderVisible[playerid]) return 1;

    // Full-screen player textdraw overlay, independent of EuroSystem UI.
    g2faReminderTD[playerid][0] = CreatePlayerTextDraw(playerid, 320.0, 0.0, "_");
    PlayerTextDrawFont(playerid, g2faReminderTD[playerid][0], 1);
    PlayerTextDrawLetterSize(playerid, g2faReminderTD[playerid][0], 0.0, 50.0);
    PlayerTextDrawTextSize(playerid, g2faReminderTD[playerid][0], 640.0, 0.0);
    PlayerTextDrawUseBox(playerid, g2faReminderTD[playerid][0], 1);
    PlayerTextDrawBoxColor(playerid, g2faReminderTD[playerid][0], 0x000000CC);
    PlayerTextDrawColor(playerid, g2faReminderTD[playerid][0], 0x00000000);

    g2faReminderTD[playerid][1] = CreatePlayerTextDraw(playerid, 320.0, 145.0, "_");
    PlayerTextDrawAlignment(playerid, g2faReminderTD[playerid][1], 2);
    PlayerTextDrawFont(playerid, g2faReminderTD[playerid][1], 1);
    PlayerTextDrawLetterSize(playerid, g2faReminderTD[playerid][1], 0.0, 17.5);
    PlayerTextDrawTextSize(playerid, g2faReminderTD[playerid][1], 430.0, 0.0);
    PlayerTextDrawUseBox(playerid, g2faReminderTD[playerid][1], 1);
    PlayerTextDrawBoxColor(playerid, g2faReminderTD[playerid][1], 0x151B27F5);
    PlayerTextDrawColor(playerid, g2faReminderTD[playerid][1], 0xFFFFFFFF);

    g2faReminderTD[playerid][2] = CreatePlayerTextDraw(playerid, 320.0, 151.0, "FUN RUSSIA  |  SECURITY CENTER");
    PlayerTextDrawAlignment(playerid, g2faReminderTD[playerid][2], 2);
    PlayerTextDrawFont(playerid, g2faReminderTD[playerid][2], 2);
    PlayerTextDrawLetterSize(playerid, g2faReminderTD[playerid][2], 0.28, 1.4);
    PlayerTextDrawColor(playerid, g2faReminderTD[playerid][2], 0xFF5555FF);
    PlayerTextDrawSetOutline(playerid, g2faReminderTD[playerid][2], 1);

    g2faReminderTD[playerid][3] = CreatePlayerTextDraw(playerid, 320.0, 179.0, "ACCOUNT PROTECTION  /  2FA");
    PlayerTextDrawAlignment(playerid, g2faReminderTD[playerid][3], 2);
    PlayerTextDrawFont(playerid, g2faReminderTD[playerid][3], 2);
    PlayerTextDrawLetterSize(playerid, g2faReminderTD[playerid][3], 0.24, 1.2);
    PlayerTextDrawColor(playerid, g2faReminderTD[playerid][3], 0xFFFFFFFF);
    PlayerTextDrawSetOutline(playerid, g2faReminderTD[playerid][3], 1);

    g2faReminderTD[playerid][4] = CreatePlayerTextDraw(playerid, 320.0, 211.0,
        "~w~\xc4\xe2\xf3\xf5\xf4\xe0\xea\xf2\xee\xf0\xed\xe0\xff\x20\xe7\xe0\xf9\xe8\xf2\xe0\x20\x32\x46\x41\x20~r~\xcd\xc5\x20\xc2\xca\xcb\xde\xd7\xc5\xcd\xc0~w~.\n\n\xc2\xe0\xf8\x20\xe0\xea\xea\xe0\xf3\xed\xf2\x20\xe0\xe4\xec\xe8\xed\xe8\xf1\xf2\xf0\xe0\xf2\xee\xf0\xe0\x20\xed\xe0\xf5\xee\xe4\xe8\xf2\xf1\xff\x20\xef\xee\xe4\x20\xf0\xe8\xf1\xea\xee\xec\x2e\x20\xcf\xf0\xe8\x20\xf3\xf2\xe5\xf7\xea\xe5\x20\xef\xe0\xf0\xee\xeb\xff\x20\xef\xee\xf1\xf2\xee\xf0\xee\xed\xed\xe8\xe9\x20\xf1\xec\xee\xe6\xe5\xf2\x20\xef\xee\xeb\xf3\xf7\xe8\xf2\xfc\x20\xe4\xee\xf1\xf2\xf3\xef\x20\xea\x20\xe0\xe4\xec\xe8\xed\xf1\xea\xe8\xec\x20\xe2\xee\xe7\xec\xee\xe6\xed\xee\xf1\xf2\xff\xec\x2e\n\n\xcf\xee\xe4\xea\xeb\xfe\xf7\xe8\xf2\xe5\x20\x47\x6f\x6f\x67\x6c\x65\x20\x41\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x6f\x72\x2c\x20\xf7\xf2\xee\xe1\xfb\x20\xe7\xe0\xf9\xe8\xf2\xe8\xf2\xfc\x20\xe0\xea\xea\xe0\xf3\xed\xf2\x2e\n\n~y~\xce\xea\xed\xee\x20\xec\xee\xe6\xed\xee\x20\xe7\xe0\xea\xf0\xfb\xf2\xfc\x2e\x20\xcd\xe0\xef\xee\xec\xe8\xed\xe0\xed\xe8\xe5\x20\xef\xee\xff\xe2\xe8\xf2\xf1\xff\x20\xf1\xed\xee\xe2\xe0\x20\xf7\xe5\xf0\xe5\xe7\x20\x35\x20\xec\xe8\xed\xf3\xf2\x2e");
    PlayerTextDrawAlignment(playerid, g2faReminderTD[playerid][4], 2);
    PlayerTextDrawFont(playerid, g2faReminderTD[playerid][4], 1);
    PlayerTextDrawLetterSize(playerid, g2faReminderTD[playerid][4], 0.22, 1.15);
    PlayerTextDrawTextSize(playerid, g2faReminderTD[playerid][4], 395.0, 0.0);
    PlayerTextDrawColor(playerid, g2faReminderTD[playerid][4], 0xE5EAF2FF);
    PlayerTextDrawSetOutline(playerid, g2faReminderTD[playerid][4], 1);
    PlayerTextDrawSetProportional(playerid, g2faReminderTD[playerid][4], 1);

    g2faReminderTD[playerid][5] = CreatePlayerTextDraw(playerid, 255.0, 306.0, "~g~[ \xcf\xce\xc4\xca\xcb\xde\xd7\xc8\xd2\xdc\x20\x32\x46\x41 ]");
    PlayerTextDrawFont(playerid, g2faReminderTD[playerid][5], 2);
    PlayerTextDrawLetterSize(playerid, g2faReminderTD[playerid][5], 0.24, 1.3);
    PlayerTextDrawColor(playerid, g2faReminderTD[playerid][5], 0xFFFFFFFF);
    PlayerTextDrawSetOutline(playerid, g2faReminderTD[playerid][5], 1);
    PlayerTextDrawSetSelectable(playerid, g2faReminderTD[playerid][5], 1);

    g2faReminderTD[playerid][6] = CreatePlayerTextDraw(playerid, 385.0, 306.0, "~r~[ \xc7\xc0\xca\xd0\xdb\xd2\xdc ]");
    PlayerTextDrawFont(playerid, g2faReminderTD[playerid][6], 2);
    PlayerTextDrawLetterSize(playerid, g2faReminderTD[playerid][6], 0.24, 1.3);
    PlayerTextDrawColor(playerid, g2faReminderTD[playerid][6], 0xFFFFFFFF);
    PlayerTextDrawSetOutline(playerid, g2faReminderTD[playerid][6], 1);
    PlayerTextDrawSetSelectable(playerid, g2faReminderTD[playerid][6], 1);

    for(new i = 0; i < 7; i++) PlayerTextDrawShow(playerid, g2faReminderTD[playerid][i]);
    SelectTextDraw(playerid, 0xFF5555FF);
    g2faReminderVisible[playerid] = true;
    return 1;
}

stock FR2FA_HideAdminReminder(playerid)
{
    if(!g2faReminderVisible[playerid]) return 1;
    CancelSelectTextDraw(playerid);
    for(new i = 0; i < 7; i++) PlayerTextDrawDestroy(playerid, g2faReminderTD[playerid][i]);
    g2faReminderVisible[playerid] = false;
    return 1;
}

public OnPlayerClickPlayerTextDraw(playerid, PlayerText:playertextid)
{
    if(!g2faReminderVisible[playerid]) return 0;
    if(playertextid == g2faReminderTD[playerid][5])
    {
        FR2FA_HideAdminReminder(playerid);
        FR2FA_OpenPurchase(playerid);
        return 1;
    }
    if(playertextid == g2faReminderTD[playerid][6])
    {
        FR2FA_HideAdminReminder(playerid);
        return 1;
    }
    return 0;
}

public OnPlayerClickTextDraw(playerid, Text:clickedid)
{
    #pragma unused clickedid
    if(g2faReminderVisible[playerid])
    {
        FR2FA_HideAdminReminder(playerid);
        return 1;
    }
    return 0;
}

stock FR2FA_LoadAccountData(playerid)
{
    if(!IsPlayerConnected(playerid) || g2faSQL == MYSQL_INVALID_HANDLE) return 0;
    new name[MAX_PLAYER_NAME], query[256], Cache:result;
    GetPlayerName(playerid, name, sizeof name);
    mysql_format(g2faSQL, query, sizeof query, "SELECT `id`, IFNULL(`admin`,0) AS admin FROM `accounts` WHERE `name`='%e' LIMIT 1", name);
    result = mysql_query(g2faSQL, query);
    if(mysql_errno(g2faSQL) != 0 || !cache_num_rows(result))
    {
        if(result) cache_delete(result);
        g2faDataLoaded[playerid] = false;
        return 0;
    }
    g2faAccountID[playerid] = cache_get_field_content_int(0, "id", g2faSQL);
    g2faAdminLevel[playerid] = cache_get_field_content_int(0, "admin", g2faSQL);
    cache_delete(result);
    if(g2faAccountID[playerid] < 1) return 0;

    mysql_format(g2faSQL, query, sizeof query, "SELECT `enabled`,`secret`,`trusted_ip` FROM `funrussia_2fa` WHERE `account_id`=%d LIMIT 1", g2faAccountID[playerid]);
    result = mysql_query(g2faSQL, query);
    if(mysql_errno(g2faSQL) != 0)
    {
        if(result) cache_delete(result);
        g2faDataLoaded[playerid] = false;
        return 0;
    }
    g2faEnabled[playerid] = false;
    g2faSecretText[playerid][0] = EOS;
    g2faLastIP[playerid][0] = EOS;
    if(cache_num_rows(result))
    {
        g2faEnabled[playerid] = cache_get_field_content_int(0, "enabled", g2faSQL) ? true : false;
        cache_get_field_content(0, "secret", g2faSecretText[playerid], g2faSQL, SECRET_B32_LEN);
        cache_get_field_content(0, "trusted_ip", g2faLastIP[playerid], g2faSQL, sizeof g2faLastIP[]);
        if(g2faSecretText[playerid][0]) FR2FA_Base32Decode(g2faSecretText[playerid], g2faSecret[playerid], SECRET_BYTES);
    }
    cache_delete(result);
    g2faDataLoaded[playerid] = true;
    if(g2faEnabled[playerid])
    {
        new currentip[46]; GetPlayerIp(playerid, currentip, sizeof currentip);
        if(strcmp(g2faLastIP[playerid], currentip, false) != 0 && !g2faPassed[playerid])
        {
            g2faPending[playerid] = true;
            TogglePlayerControllable(playerid, 0);
            ShowPlayerDialog(playerid, DLG_2FA_VERIFY, DIALOG_STYLE_INPUT,
                "�������������� ������", "IP-����� ���������. ������� 6-������� ��� Google Authenticator. �� ������������� �������� ��������� �� �����.", "�����������", "�����");
        }
    }
    return 1;
}

stock FR2FA_SaveAccountData(playerid, enabled, const secret[], const trustedIP[], setupPaid)
{
    if(!IsPlayerConnected(playerid) || g2faSQL == MYSQL_INVALID_HANDLE || g2faAccountID[playerid] < 1) return 0;
    new query[512], Cache:result;
    mysql_format(g2faSQL, query, sizeof query,
        "INSERT INTO `funrussia_2fa` (`account_id`,`enabled`,`secret`,`trusted_ip`,`setup_paid`) VALUES (%d,%d,'%e','%e',%d) ON DUPLICATE KEY UPDATE `enabled`=%d,`secret`='%e',`trusted_ip`='%e',`setup_paid`=%d",
        g2faAccountID[playerid], enabled ? 1 : 0, secret, trustedIP, setupPaid ? 1 : 0,
        enabled ? 1 : 0, secret, trustedIP, setupPaid ? 1 : 0);
    result = mysql_query(g2faSQL, query);
    new error = mysql_errno(g2faSQL);
    if(result) cache_delete(result);
    if(error != 0) return 0;
    g2faEnabled[playerid] = enabled ? true : false;
    format(g2faSecretText[playerid], SECRET_B32_LEN, "%s", secret);
    format(g2faLastIP[playerid], sizeof g2faLastIP[], "%s", trustedIP);
    return 1;
}

stock FR2FA_Trim(string[])
{
    new len = strlen(string), start = 0, i;
    while(start < len && (string[start] == ' ' || string[start] == '\t' || string[start] == '\r' || string[start] == '\n')) start++;
    if(start > 0)
    {
        for(i = 0; i <= len - start; i++) string[i] = string[start + i];
        len -= start;
    }
    while(len > 0 && (string[len - 1] == ' ' || string[len - 1] == '\t' || string[len - 1] == '\r' || string[len - 1] == '\n'))
        string[--len] = EOS;
    return 1;
}

stock bool:FR2FA_LoadIni()
{
    format(g2faSQLHost, sizeof g2faSQLHost, "127.0.0.1");
    g2faSQLUser[0] = g2faSQLPass[0] = g2faSQLDB[0] = EOS;
    if(!fexist(MYSQL_FILE)) return false;
    new File:f = fopen(MYSQL_FILE, io_read), line[256];
    if(!f) return false;
    while(fread(f, line))
    {
        stripnewline(line); FR2FA_Trim(line);
        if(!line[0] || line[0] == ';' || line[0] == '#' || line[0] == '[') continue;
        new eq = strfind(line, "="); if(eq < 1) continue;
        new key[64], val[128];
        strmid(key, line, 0, eq); strmid(val, line, eq + 1, strlen(line)); FR2FA_Trim(key); FR2FA_Trim(val);
        if(!strcmp(key, "host", true) || !strcmp(key, "hostname", true) || !strcmp(key, "server", true)) format(g2faSQLHost, sizeof g2faSQLHost, "%s", val);
        else if(!strcmp(key, "username", true) || !strcmp(key, "user", true) || !strcmp(key, "login", true)) format(g2faSQLUser, sizeof g2faSQLUser, "%s", val);
        else if(!strcmp(key, "password", true) || !strcmp(key, "pass", true)) format(g2faSQLPass, sizeof g2faSQLPass, "%s", val);
        else if(!strcmp(key, "database", true) || !strcmp(key, "db", true) || !strcmp(key, "dbname", true)) format(g2faSQLDB, sizeof g2faSQLDB, "%s", val);
    }
    fclose(f);
    return (g2faSQLUser[0] && g2faSQLDB[0]);
}

stock FR2FA_ConnectSQL()
{
    g2faSQL = mysql_connect(g2faSQLHost, g2faSQLUser, g2faSQLDB, g2faSQLPass);
    if(g2faSQL && mysql_errno(g2faSQL) == 0)
    {
        mysql_tquery(g2faSQL, "SET NAMES 'cp1251'");
        mysql_tquery(g2faSQL, "SET CHARACTER SET cp1251");
        return 1;
    }
    g2faSQL = MYSQL_INVALID_HANDLE;
    return 0;
}

stock FR2FA_ShowSecret(playerid)
{
    new msg[256];
    format(msg, sizeof msg, "��������� ����: %s\n\n�������� ��� � Google Authenticator ������� (��� �����: �� ������� / TOTP), ����� ����������� ���. ���� ������� ����, ��������� ����� ���������� ����� ���� ��������� ��� ��������� ������.", g2faSecretText[playerid]);
    ShowPlayerDialog(playerid, DLG_2FA_CONFIRM, DIALOG_STYLE_MSGBOX,
        "��������� 2FA", msg, "������ ���", "�����");
    return 1;
}

stock FR2FA_GenerateSecret(playerid)
{
    // Pawn's built-in PRNG is used because this filterscript has no crypto plugin dependency.
    // For high-security deployment, replace with a cryptographically secure random source.
    for(new i = 0; i < SECRET_BYTES; i++) g2faSecret[playerid][i] = random(256);
    FR2FA_Base32Encode(g2faSecret[playerid], SECRET_BYTES, g2faSecretText[playerid], SECRET_B32_LEN);
    return 1;
}

stock FR2FA_Verify(playerid, const code[])
{
    if(strlen(code) != 6) return 0;
    for(new i; i < 6; i++) if(code[i] < '0' || code[i] > '9') return 0;
    new supplied = strval(code), step = gettime() / 30, expected;
    // Accept adjacent time windows to tolerate small clock drift.
    for(new off = -1; off <= 1; off++)
    {
        expected = FR2FA_TOTP(g2faSecret[playerid], step + off);
        if(expected == supplied && step + off != g2faLastStep[playerid])
        {
            g2faLastStep[playerid] = step + off;
            return 1;
        }
    }
    return 0;
}

stock FR2FA_TOTP(const secret[], step)
{
    new msg[8];
    for(new i = 7; i >= 0; i--) { msg[i] = step & 0xFF; step = step >>> 8; }
    new mac[20]; FR2FA_HMAC_SHA1(secret, SECRET_BYTES, msg, sizeof msg, mac);
    new offset = mac[19] & 0x0F;
    new binary = ((mac[offset] & 0x7F) << 24) | ((mac[offset+1] & 0xFF) << 16) | ((mac[offset+2] & 0xFF) << 8) | (mac[offset+3] & 0xFF);
    return binary % 1000000;
}

stock FR2FA_HMAC_SHA1(const key[], keylen, const msg[], msglen, out[])
{
    new inner[MAX_SHA_BYTES], outer[MAX_SHA_BYTES], digest[20], i;
    for(i = 0; i < 64; i++)
    {
        new k = (i < keylen) ? key[i] : 0;
        inner[i] = k ^ 0x36; outer[i] = k ^ 0x5C;
    }
    for(i = 0; i < msglen; i++) inner[64+i] = msg[i];
    FR2FA_SHA1(inner, 64 + msglen, digest);
    for(i = 0; i < 20; i++) outer[64+i] = digest[i];
    FR2FA_SHA1(outer, 84, out);
    return 1;
}

stock FR2FA_SHA1(const input[], inputLen, output[])
{
    new data[MAX_SHA_BYTES], len = inputLen, i;
    if(len > 180) return 0;
    for(i = 0; i < len; i++) data[i] = input[i] & 0xFF;
    data[len++] = 0x80;
    while((len % 64) != 56) data[len++] = 0;
    new high = 0, low = inputLen * 8;
    data[len++] = (high >>> 24) & 0xFF; data[len++] = (high >>> 16) & 0xFF; data[len++] = (high >>> 8) & 0xFF; data[len++] = high & 0xFF;
    data[len++] = (low >>> 24) & 0xFF; data[len++] = (low >>> 16) & 0xFF; data[len++] = (low >>> 8) & 0xFF; data[len++] = low & 0xFF;
    new h0 = 0x67452301, h1 = 0xEFCDAB89, h2 = 0x98BADCFE, h3 = 0x10325476, h4 = 0xC3D2E1F0;
    new w[80], a, b, c, d, e, f, k, temp, j, block;
    for(block = 0; block < len; block += 64)
    {
        for(i = 0; i < 16; i++)
        {
            j = block + i*4;
            w[i] = ((data[j] & 0xFF) << 24) | ((data[j+1] & 0xFF) << 16) | ((data[j+2] & 0xFF) << 8) | (data[j+3] & 0xFF);
        }
        for(i = 16; i < 80; i++) w[i] = FR2FA_ROL(w[i-3] ^ w[i-8] ^ w[i-14] ^ w[i-16], 1);
        a = h0; b = h1; c = h2; d = h3; e = h4;
        for(i = 0; i < 80; i++)
        {
            if(i < 20) { f = (b & c) | ((~b) & d); k = 0x5A827999; }
            else if(i < 40) { f = b ^ c ^ d; k = 0x6ED9EBA1; }
            else if(i < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8F1BBCDC; }
            else { f = b ^ c ^ d; k = 0xCA62C1D6; }
            temp = FR2FA_ROL(a, 5) + f + e + k + w[i];
            e = d; d = c; c = FR2FA_ROL(b, 30); b = a; a = temp;
        }
        h0 += a; h1 += b; h2 += c; h3 += d; h4 += e;
    }
    output[0] = (h0 >>> 24) & 0xFF; output[1] = (h0 >>> 16) & 0xFF; output[2] = (h0 >>> 8) & 0xFF; output[3] = h0 & 0xFF;
    output[4] = (h1 >>> 24) & 0xFF; output[5] = (h1 >>> 16) & 0xFF; output[6] = (h1 >>> 8) & 0xFF; output[7] = h1 & 0xFF;
    output[8] = (h2 >>> 24) & 0xFF; output[9] = (h2 >>> 16) & 0xFF; output[10] = (h2 >>> 8) & 0xFF; output[11] = h2 & 0xFF;
    output[12] = (h3 >>> 24) & 0xFF; output[13] = (h3 >>> 16) & 0xFF; output[14] = (h3 >>> 8) & 0xFF; output[15] = h3 & 0xFF;
    output[16] = (h4 >>> 24) & 0xFF; output[17] = (h4 >>> 16) & 0xFF; output[18] = (h4 >>> 8) & 0xFF; output[19] = h4 & 0xFF;
    return 1;
}

stock FR2FA_ROL(value, bits) return (value << bits) | (value >>> (32 - bits));

stock FR2FA_Base32Encode(const bytes[], len, output[], outsize)
{
    static const alphabet[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
    new buffer, bits, index;
    for(new i = 0; i < len; i++)
    {
        buffer = (buffer << 8) | (bytes[i] & 0xFF); bits += 8;
        while(bits >= 5)
        {
            bits -= 5;
            if(index < outsize - 1) output[index++] = alphabet[(buffer >>> bits) & 31];
        }
    }
    if(bits && index < outsize - 1) output[index++] = alphabet[(buffer << (5 - bits)) & 31];
    output[index] = EOS; return index;
}

stock FR2FA_Base32Decode(const input[], output[], maxbytes)
{
    new buffer, bits, count, val;
    for(new i = 0; input[i]; i++)
    {
        val = FR2FA_Base32Value(input[i]); if(val < 0) return 0;
        buffer = (buffer << 5) | val; bits += 5;
        if(bits >= 8)
        {
            bits -= 8;
            if(count >= maxbytes) return 0;
            output[count++] = (buffer >>> bits) & 0xFF;
        }
    }
    return count == maxbytes;
}

stock FR2FA_Base32Value(ch)
{
    if(ch >= 'A' && ch <= 'Z') return ch - 'A';
    if(ch >= 'a' && ch <= 'z') return ch - 'a';
    if(ch >= '2' && ch <= '7') return ch - '2' + 26;
    return -1;
}

stock stripnewline(text[])
{
    for(new i; text[i]; i++) if(text[i] == '\r' || text[i] == '\n') { text[i] = EOS; break; }
    return 1;
}
