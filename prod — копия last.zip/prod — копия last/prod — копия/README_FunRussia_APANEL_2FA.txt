Fun Russia — A-panel + admin 2FA reminder (filterscripts only)

Files in this package:
- EuroSystem_GUI_APANEL.pwn — EuroSystem GUI with A-panel access checks based on accounts.admin.
- FunRussia_2FA_ADMIN_REMINDER.pwn — standalone MySQL-backed 2FA filterscript with the admin reminder.

A-panel:
- Access: admin levels 5 through 13 inclusive.
- Admin level is read from accounts.admin by the EuroSystem account-loading query; no FRAP_GetAdminLevel gamemode callback is required.
- Logs, online/offline admin lists, server announcements and info templates remain in the panel.
- Mass rewards are intentionally disabled. Safely updating live players' cash/donate balance/levels requires an existing gamemode callback or a deliberate gamemode integration. Direct SQL writes from a filterscript could desynchronize live memory and database state. The gamemode source is not included or modified.

2FA reminder:
- Uses the standalone 2FA source's existing MySQL configuration file: bykranin_mysql_settings.ini.
- On spawn, the filterscript reads accounts.id and accounts.admin, then checks funrussia_2fa.
- Admins levels 5–13 without enabled 2FA see a warning with a button that opens the existing 2FA setup flow.
- Closing the warning is allowed; it repeats every 5 minutes while 2FA remains disabled.
- Existing setup uses the existing EuroSystem charge/refund callbacks for FC. Therefore EuroSystem must be loaded and its existing FR2FA_ChargeFC / FR2FA_RefundFC functions must be present, as in the 2FA integration source.

Important validation notes:
- No gamemode source is included in this package.
- This environment did not have the Pawn compiler available, so these sources have not been compile-verified here. Test on a backup/test server first.
- The 2FA source is based on FunRussia_2FA_fixed.pwn (the standalone MySQL-backed version). The zero-byte file named FunRussia_2FA_CRASHFIX.pwn was not used.
- The A-panel is integrated in EuroSystem GUI, not a separate gamemode command.
